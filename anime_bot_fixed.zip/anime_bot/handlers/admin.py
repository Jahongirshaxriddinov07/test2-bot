from __future__ import annotations

import asyncio
import json
import logging
import math

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import config
import keyboards as kb
from database import Database
from handlers import user as user_handlers
from handlers.common import IsAdminFilter, ensure_user, fmt_number
from states import AddAnimeStates, AddEpisodeStates, AdminTextStates, BroadcastStates, EditAnimeStates

logger = logging.getLogger("anime_bot.admin")
router = Router(name="admin")
router.message.filter(IsAdminFilter())
router.callback_query.filter(IsAdminFilter())

PER_PAGE = 10

# broadcast_id -> {"paused": bool, "cancel": bool}
_broadcast_flags: dict[int, dict] = {}


# ------------------------------------------------------------------ #
# GLOBAL: Bekor qilish / /start / /cancel — har qanday FSM holatidan
# MAJBURIY chiqarish uchun (bu handlerlar shu routerdagi eng yuqorida
# turgani uchun, pastdagi har bir "waiting_..." bosqichidan USTUN keladi
# va admin hech qachon "Iltimos ... yuboring" degan holatda qolib
# ketmaydi, hatto /start yoki /cancel yozsa ham).
# ------------------------------------------------------------------ #
@router.message(F.text == "❌ Bekor qilish")
async def admin_cancel_any(message: Message, state: FSMContext, db: Database):
    await user_handlers.cancel_any(message, db, state)


@router.message(Command("cancel"))
async def admin_cancel_command(message: Message, state: FSMContext, db: Database):
    await user_handlers.cancel_any(message, db, state)


@router.message(CommandStart())
async def admin_start_override(message: Message, state: FSMContext, db: Database):
    await user_handlers.cmd_start(message, db, state)


# ------------------------------------------------------------------ #
# Kirish
# ------------------------------------------------------------------ #
@router.message(F.text == "⚙️ Admin panel")
async def open_admin_panel(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "⚙️ <b>Admin panel</b>\n\nBo'limni tanlang:",
        reply_markup=kb.admin_panel_menu(),
    )
    await message.answer(
        "Foydalanuvchi paneliga qaytish uchun tugmadan foydalaning 👇",
        reply_markup=kb.admin_back_to_user_menu(),
    )


@router.callback_query(F.data == "adm:panel")
async def back_to_panel(call: CallbackQuery, state: FSMContext):
    await state.clear()
    try:
        await call.message.edit_text("⚙️ <b>Admin panel</b>\n\nBo'limni tanlang:", reply_markup=kb.admin_panel_menu())
    except TelegramBadRequest:
        await call.message.answer("⚙️ <b>Admin panel</b>\n\nBo'limni tanlang:", reply_markup=kb.admin_panel_menu())
    await call.answer()


# ------------------------------------------------------------------ #
# Statistika
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:stats")
async def stats(call: CallbackQuery, db: Database):
    s = await db.stats()
    text = (
        "📊 <b>Statistika</b>\n\n"
        f"👥 Foydalanuvchilar: {fmt_number(s['users'])}\n"
        f"💎 VIP foydalanuvchilar: {fmt_number(s['vip_users'])}\n"
        f"🎬 Animelar: {fmt_number(s['anime'])}\n"
        f"📼 Qismlar: {fmt_number(s['episodes'])}"
    )
    await call.message.answer(text, reply_markup=kb.admin_back_button())
    await call.answer()


# ------------------------------------------------------------------ #
# Anime qo'shish
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:add_anime")
async def add_anime_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(AddAnimeStates.waiting_title)
    await call.message.answer("➕ Yangi anime nomini kiriting:", reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(AddAnimeStates.waiting_title)
async def add_anime_title(message: Message, state: FSMContext):
    if not message.text:
        await message.answer("✏️ Iltimos, anime nomini matn ko'rinishida yuboring.")
        return
    await state.update_data(new_title=message.text.strip())
    await state.set_state(AddAnimeStates.waiting_description)
    await message.answer("📝 Anime tavsifini kiriting (yoki «-» deb yozing, tavsifsiz qo'shish uchun):")


@router.message(AddAnimeStates.waiting_description)
async def add_anime_description(message: Message, state: FSMContext):
    if not message.text:
        await message.answer("✏️ Iltimos, tavsifni matn ko'rinishida yuboring (yoki «-»).")
        return
    desc = message.text.strip()
    await state.update_data(new_description="" if desc == "-" else desc)
    await state.set_state(AddAnimeStates.waiting_poster)
    await message.answer("🖼 Anime uchun poster rasm yuboring (yoki «-» deb yozing, rasmsiz qo'shish uchun):")


@router.message(AddAnimeStates.waiting_poster, F.photo)
async def add_anime_poster(message: Message, state: FSMContext, db: Database):
    await state.update_data(new_poster=message.photo[-1].file_id)
    await _ask_genres(message, state, db)


@router.message(AddAnimeStates.waiting_poster, F.text == "-")
async def add_anime_no_poster(message: Message, state: FSMContext, db: Database):
    await state.update_data(new_poster=None)
    await _ask_genres(message, state, db)


@router.message(AddAnimeStates.waiting_poster)
async def add_anime_poster_wrong(message: Message):
    await message.answer("🖼 Rasm yuboring yoki rasmsiz o'tish uchun «-» deb yozing.")


async def _ask_genres(message: Message, state: FSMContext, db: Database):
    await state.update_data(selected_genres=[])
    await state.set_state(AddAnimeStates.waiting_genres)
    genres = await db.list_genres()
    await message.answer(
        "🎭 Janr(lar)ni tanlang (bir nechtasini belgilash mumkin), so'ng ✅ Tayyor bosing:",
        reply_markup=kb.genres_menu(genres, selected_ids=set(), for_admin_add=True),
    )


@router.callback_query(AddAnimeStates.waiting_genres, F.data.startswith("pick_genre:"))
async def add_anime_pick_genre(call: CallbackQuery, state: FSMContext, db: Database):
    value = call.data.split(":")[1]
    data = await state.get_data()
    selected: list[int] = data.get("selected_genres", [])

    if value == "done":
        title = data["new_title"]
        description = data.get("new_description") or ""
        poster = data.get("new_poster")
        anime = await db.create_anime(title, description, poster, selected)
        await state.clear()
        vip_note = " (💎 VIP anime deb belgilandi)" if anime["is_vip"] else ""
        await call.message.answer(
            f"✅ «{anime['title']}» qo'shildi! ID: <code>{anime['anime_code']}</code>{vip_note}\n\n"
            f"Endi qismlarni (video) qo'shishingiz mumkin.",
            reply_markup=kb.admin_anime_detail_keyboard(anime["id"]),
        )
        await call.answer()
        return

    genre_id = int(value)
    if genre_id in selected:
        selected.remove(genre_id)
    else:
        selected.append(genre_id)
    await state.update_data(selected_genres=selected)
    genres = await db.list_genres()
    try:
        await call.message.edit_reply_markup(
            reply_markup=kb.genres_menu(genres, selected_ids=set(selected), for_admin_add=True)
        )
    except TelegramBadRequest:
        pass
    await call.answer()


# ------------------------------------------------------------------ #
# Animelar ro'yxati / detali (admin)
# ------------------------------------------------------------------ #
@router.callback_query(F.data.startswith("adm:anime_list:"))
async def admin_anime_list(call: CallbackQuery, db: Database):
    page = int(call.data.split(":")[2])
    rows = (await db.all_anime_for_random())
    rows.sort(key=lambda r: r["created_at"], reverse=True)
    total_pages = max(1, math.ceil(len(rows) / PER_PAGE))
    page_rows = rows[page * PER_PAGE:(page + 1) * PER_PAGE]
    text = f"🎬 <b>Animelar</b> ({len(rows)} ta):" if rows else "Hali anime qo'shilmagan."
    markup = kb.admin_anime_list_keyboard(page_rows, page, total_pages)
    try:
        await call.message.edit_text(text, reply_markup=markup)
    except TelegramBadRequest:
        await call.message.answer(text, reply_markup=markup)
    await call.answer()


@router.callback_query(F.data.startswith("adm:anime:"))
async def admin_anime_detail(call: CallbackQuery, db: Database):
    anime_id = int(call.data.split(":")[2])
    anime = await db.get_anime(anime_id)
    if not anime:
        await call.answer("Topilmadi.", show_alert=True)
        return
    genres = await db.get_anime_genres(anime_id)
    genre_txt = ", ".join(f"{g['emoji']} {g['name']}" for g in genres) or "—"
    ep_count = await db.count_episodes(anime_id)
    text = (
        f"🎬 <b>{anime['title']}</b>\n"
        f"🆔 ID: <code>{anime['anime_code']}</code>\n"
        f"🎭 Janr: {genre_txt}\n"
        f"📼 Qismlar: {ep_count}\n"
        f"{'💎 VIP' if anime['is_vip'] else '🆓 Oddiy'}\n\n"
        f"{anime['description'] or ''}"
    )
    await call.message.answer(text, reply_markup=kb.admin_anime_detail_keyboard(anime_id))
    await call.answer()


@router.callback_query(F.data.startswith("adm:edit_title:"))
async def admin_edit_title_start(call: CallbackQuery, state: FSMContext):
    anime_id = int(call.data.split(":")[2])
    await state.update_data(edit_anime_id=anime_id)
    await state.set_state(EditAnimeStates.waiting_new_title)
    await call.message.answer("✏️ Yangi nomni kiriting:", reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(EditAnimeStates.waiting_new_title)
async def admin_edit_title_save(message: Message, state: FSMContext, db: Database):
    if not message.text:
        await message.answer("✏️ Iltimos, matn yuboring.")
        return
    data = await state.get_data()
    anime_id = data["edit_anime_id"]
    await db.conn.execute("UPDATE anime SET title=? WHERE id=?", (message.text.strip(), anime_id))
    await db.conn.commit()
    await state.clear()
    user = await ensure_user(db, message.from_user)
    await message.answer("✅ Nomi yangilandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


@router.callback_query(F.data.startswith("adm:edit_desc:"))
async def admin_edit_desc_start(call: CallbackQuery, state: FSMContext):
    anime_id = int(call.data.split(":")[2])
    await state.update_data(edit_anime_id=anime_id)
    await state.set_state(EditAnimeStates.waiting_new_description)
    await call.message.answer("✏️ Yangi tavsifni kiriting:", reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(EditAnimeStates.waiting_new_description)
async def admin_edit_desc_save(message: Message, state: FSMContext, db: Database):
    if not message.text:
        await message.answer("✏️ Iltimos, matn yuboring.")
        return
    data = await state.get_data()
    anime_id = data["edit_anime_id"]
    await db.conn.execute("UPDATE anime SET description=? WHERE id=?", (message.text.strip(), anime_id))
    await db.conn.commit()
    await state.clear()
    await message.answer("✅ Tavsif yangilandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


@router.callback_query(F.data.startswith("adm:edit_genres:"))
async def admin_edit_genres_start(call: CallbackQuery, state: FSMContext, db: Database):
    anime_id = int(call.data.split(":")[2])
    current = await db.get_anime_genres(anime_id)
    selected = [g["id"] for g in current]
    await state.update_data(edit_anime_id=anime_id, selected_genres=selected)
    await state.set_state(EditAnimeStates.waiting_genres)
    genres = await db.list_genres()
    await call.message.answer(
        "🎭 Janrlarni belgilang, so'ng ✅ Tayyor bosing:",
        reply_markup=kb.genres_menu(genres, selected_ids=set(selected), for_admin_add=True),
    )
    await call.answer()


@router.callback_query(EditAnimeStates.waiting_genres, F.data.startswith("pick_genre:"))
async def admin_edit_genres_pick(call: CallbackQuery, state: FSMContext, db: Database):
    value = call.data.split(":")[1]
    data = await state.get_data()
    selected: list[int] = data.get("selected_genres", [])
    anime_id = data["edit_anime_id"]

    if value == "done":
        await db.update_anime_genres(anime_id, selected)
        await state.clear()
        await call.message.answer("✅ Janrlar yangilandi.", reply_markup=kb.admin_anime_detail_keyboard(anime_id))
        await call.answer()
        return

    genre_id = int(value)
    if genre_id in selected:
        selected.remove(genre_id)
    else:
        selected.append(genre_id)
    await state.update_data(selected_genres=selected)
    genres = await db.list_genres()
    try:
        await call.message.edit_reply_markup(
            reply_markup=kb.genres_menu(genres, selected_ids=set(selected), for_admin_add=True)
        )
    except TelegramBadRequest:
        pass
    await call.answer()


@router.callback_query(F.data.startswith("adm:delete_anime_confirm:"))
async def admin_delete_confirm(call: CallbackQuery):
    anime_id = int(call.data.split(":")[2])
    await call.message.answer(
        "🗑 Rostdan ham ushbu animeni (barcha qismlari bilan) o'chirmoqchimisiz?",
        reply_markup=kb.confirm_delete_keyboard(anime_id),
    )
    await call.answer()


@router.callback_query(F.data.startswith("adm:delete_anime:"))
async def admin_delete_anime(call: CallbackQuery, db: Database):
    anime_id = int(call.data.split(":")[2])
    await db.conn.execute("DELETE FROM anime WHERE id=?", (anime_id,))
    await db.conn.commit()
    await call.message.edit_text("🗑 Anime o'chirildi.")
    await call.answer()


# ------------------------------------------------------------------ #
# Qism qo'shish
# ------------------------------------------------------------------ #
@router.callback_query(F.data.startswith("adm:add_episode:"))
async def add_episode_start(call: CallbackQuery, state: FSMContext):
    anime_id = int(call.data.split(":")[2])
    await state.update_data(episode_anime_id=anime_id, episode_videos=[])
    await state.set_state(AddEpisodeStates.waiting_video)
    await call.message.answer(
        "📼 Video(lar)ni birma-bir yuboring.\n\n"
        "✅ <b>Tayyor</b> — barcha yuborilgan videolarni qism sifatida saqlaydi.\n"
        "❌ <b>Bekor qilish</b> — hech narsa saqlamay chiqib ketadi.",
        reply_markup=kb.episode_upload_keyboard(),
    )
    await call.answer()


@router.message(AddEpisodeStates.waiting_video, F.video)
async def add_episode_video(message: Message, state: FSMContext):
    data = await state.get_data()
    videos: list[str] = data.get("episode_videos", [])
    videos.append(message.video.file_id)
    await state.update_data(episode_videos=videos)
    await message.answer(
        f"✅ Qabul qilindi (jami: {len(videos)} ta video).\n"
        f"Yana video yuboring yoki ✅ Tayyor tugmasini bosing.",
        reply_markup=kb.episode_upload_keyboard(),
    )


@router.message(AddEpisodeStates.waiting_video)
async def add_episode_wrong_type(message: Message):
    await message.answer(
        "📼 Iltimos video fayl yuboring (yoki pastdagi ✅ Tayyor / ❌ Bekor qilish tugmasidan foydalaning).",
        reply_markup=kb.episode_upload_keyboard(),
    )


@router.callback_query(AddEpisodeStates.waiting_video, F.data == "adm:episodes_done")
async def add_episode_done(call: CallbackQuery, state: FSMContext, db: Database):
    data = await state.get_data()
    anime_id = data.get("episode_anime_id")
    videos: list[str] = data.get("episode_videos", [])
    await state.clear()

    if not videos:
        await call.answer("❗ Hech qanday video yuborilmadi.", show_alert=True)
        if anime_id:
            anime = await db.get_anime(anime_id)
            if anime:
                await call.message.answer(
                    f"🎬 <b>{anime['title']}</b>",
                    reply_markup=kb.admin_anime_detail_keyboard(anime_id),
                )
        return

    last_episode = None
    for file_id in videos:
        last_episode = await db.add_episode(anime_id, file_id)

    await call.message.answer(
        f"✅ {len(videos)} ta qism saqlandi "
        f"(oxirgi qo'shilgani: {last_episode['episode_number']}-qism).",
        reply_markup=kb.admin_anime_detail_keyboard(anime_id),
    )
    await call.answer()


@router.callback_query(AddEpisodeStates.waiting_video, F.data == "adm:episodes_cancel")
async def add_episode_cancel(call: CallbackQuery, state: FSMContext, db: Database):
    data = await state.get_data()
    anime_id = data.get("episode_anime_id")
    await state.clear()
    await call.answer("Bekor qilindi. Hech narsa saqlanmadi.", show_alert=True)
    if anime_id:
        anime = await db.get_anime(anime_id)
        if anime:
            await call.message.answer(
                f"🎬 <b>{anime['title']}</b>",
                reply_markup=kb.admin_anime_detail_keyboard(anime_id),
            )


# ------------------------------------------------------------------ #
# Kanalga e'lon qilish
# ------------------------------------------------------------------ #
@router.callback_query(F.data.startswith("adm:announce:"))
async def announce_anime(call: CallbackQuery, db: Database, bot: Bot):
    anime_id = int(call.data.split(":")[2])
    if not config.MAIN_CHANNEL:
        await call.answer("MAIN_CHANNEL .env faylida sozlanmagan.", show_alert=True)
        return
    ok = await _post_announcement(bot, db, anime_id)
    await call.answer("📢 Kanalga e'lon qilindi!" if ok else "❌ Xatolik yuz berdi.", show_alert=True)


async def _post_announcement(bot: Bot, db: Database, anime_id: int) -> bool:
    anime = await db.get_anime(anime_id)
    if not anime:
        return False
    genres = await db.get_anime_genres(anime_id)
    genre_txt = ", ".join(f"{g['emoji']} {g['name']}" for g in genres) or "—"
    bot_info = await bot.get_me()
    caption = (
        f"🆕 <b>{anime['title']}</b>\n\n"
        f"🆔 Anime ID: <code>{anime['anime_code']}</code>\n"
        f"🎭 Janr: {genre_txt}\n"
        f"{anime['description'] or ''}"
    )
    markup = kb.InlineKeyboardMarkup(inline_keyboard=[[
        kb.InlineKeyboardButton(
            text="▶️ Animeni ko'rish",
            url=f"https://t.me/{bot_info.username}?start=anime_{anime['anime_code']}",
        )
    ]])
    try:
        if anime["poster_file_id"]:
            await bot.send_photo(config.MAIN_CHANNEL, anime["poster_file_id"], caption=caption, reply_markup=markup)
        else:
            await bot.send_message(config.MAIN_CHANNEL, caption, reply_markup=markup)
        return True
    except Exception:
        logger.exception("Kanalga e'lon qilishda xatolik")
        return False


# ------------------------------------------------------------------ #
# Foydalanuvchilar
# ------------------------------------------------------------------ #
@router.callback_query(F.data.startswith("adm:users:"))
async def admin_users_list(call: CallbackQuery, db: Database):
    page = int(call.data.split(":")[2])
    total = await db.count_users()
    rows = await db.list_users(page, PER_PAGE)
    total_pages = max(1, math.ceil(total / PER_PAGE))
    text = f"👥 <b>Foydalanuvchilar</b> ({total} ta):"
    markup = kb.admin_users_list_keyboard(rows, page, total_pages)
    try:
        await call.message.edit_text(text, reply_markup=markup)
    except TelegramBadRequest:
        await call.message.answer(text, reply_markup=markup)
    await call.answer()


@router.callback_query(F.data.startswith("adm:user:"))
async def admin_user_detail(call: CallbackQuery, db: Database):
    telegram_id = int(call.data.split(":")[2])
    user = await db.get_user(telegram_id)
    if not user:
        await call.answer("Topilmadi.", show_alert=True)
        return
    is_vip = await db.is_vip(telegram_id)
    favs = await db.list_favorites(telegram_id)
    history = await db.list_watch_history(telegram_id, limit=1000)
    cur = await db.conn.execute(
        "SELECT COUNT(*) FROM vip_purchases WHERE user_id=?", (user["id"],)
    )
    (vip_purchase_count,) = await cur.fetchone()

    username_line = f"🔗 Username: @{user['username']}\n" if user["username"] else "🔗 Username: —\n"
    text = (
        f"👤 <b>{user['full_name']}</b>\n"
        f"🆔 ID: <code>{user['telegram_id']}</code>\n"
        f"{username_line}"
    )
    text += (
        f"📊 Status: {'🛡 Admin' if user['is_admin'] else ('💎 VIP' if is_vip else '👤 Oddiy')}\n"
        f"⏳ VIP muddati: {user['vip_until'][:10] if is_vip and user['vip_until'] else '—'}\n"
        f"💰 Balans: {fmt_number(user['balance'])} so'm\n"
        f"💎 VIP xaridlar: {vip_purchase_count} ta\n"
        f"❤️ Sevimlilar: {len(favs)} ta\n"
        f"📚 Ko'rilganlar: {len(history)} ta\n"
        f"📅 Qo'shilgan: {user['joined_at'][:10]}"
    )
    await call.message.answer(text, reply_markup=kb.admin_user_detail_keyboard(telegram_id, bool(user["is_admin"])))
    await call.answer()


@router.callback_query(F.data.startswith("adm:make_admin:"))
async def make_admin(call: CallbackQuery, db: Database):
    telegram_id = int(call.data.split(":")[2])
    await db.set_admin(telegram_id, True)
    await call.answer("✅ Admin qilindi.", show_alert=True)


@router.callback_query(F.data.startswith("adm:revoke_admin:"))
async def revoke_admin(call: CallbackQuery, db: Database):
    telegram_id = int(call.data.split(":")[2])
    await db.set_admin(telegram_id, False)
    await call.answer("✅ Admin huquqi olib tashlandi.", show_alert=True)


@router.callback_query(F.data.startswith("adm:grant_vip_menu:"))
async def grant_vip_menu(call: CallbackQuery):
    telegram_id = int(call.data.split(":")[2])
    await call.message.answer("💎 Muddatni tanlang:", reply_markup=kb.grant_vip_keyboard(telegram_id))
    await call.answer()


@router.callback_query(F.data.startswith("grant_vip:"))
async def grant_vip(call: CallbackQuery, db: Database, bot: Bot):
    _, telegram_id_str, months_str = call.data.split(":")
    telegram_id, months = int(telegram_id_str), int(months_str)
    new_until = await db.grant_vip(telegram_id, months, price=0, source="admin_grant",
                                    approved_by=call.from_user.id)
    await call.message.answer(f"✅ VIP berildi. Tugash sanasi: {new_until.date()}")
    await call.answer()
    try:
        await bot.send_message(
            telegram_id,
            f"🎉 Sizga admin tomonidan {months} oylik 💎 VIP status berildi!\n"
            f"⏳ Amal qilish muddati: {new_until.date()} gacha.",
        )
    except Exception:
        pass


# ------------------------------------------------------------------ #
# VIP to'lovlarini tasdiqlash / rad etish
# ------------------------------------------------------------------ #
@router.callback_query(F.data.startswith("pay_approve:"))
async def pay_approve(call: CallbackQuery, db: Database, bot: Bot):
    payment_id = int(call.data.split(":")[1])
    payment = await db.get_pending_payment(payment_id)
    if not payment or payment["status"] != "pending":
        await call.answer("Bu to'lov allaqachon ko'rib chiqilgan.", show_alert=True)
        return
    user = await db.get_user_by_pk(payment["user_id"])
    new_until = await db.grant_vip(
        user["telegram_id"], payment["months"], payment["price"], source="payment",
        approved_by=call.from_user.id,
    )
    await db.resolve_payment(payment_id, "approved", call.from_user.id)
    try:
        await call.message.edit_caption(caption=(call.message.caption or "") + "\n\n✅ TASDIQLANDI")
    except TelegramBadRequest:
        pass
    await call.answer("✅ VIP berildi.")
    try:
        await bot.send_message(
            user["telegram_id"],
            f"🎉 To'lovingiz tasdiqlandi! 💎 VIP faollashtirildi.\n"
            f"⏳ Amal qilish muddati: {new_until.date()} gacha.",
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("pay_reject:"))
async def pay_reject(call: CallbackQuery, db: Database, bot: Bot):
    payment_id = int(call.data.split(":")[1])
    payment = await db.get_pending_payment(payment_id)
    if not payment or payment["status"] != "pending":
        await call.answer("Bu to'lov allaqachon ko'rib chiqilgan.", show_alert=True)
        return
    await db.resolve_payment(payment_id, "rejected", call.from_user.id)
    user = await db.get_user_by_pk(payment["user_id"])
    try:
        await call.message.edit_caption(caption=(call.message.caption or "") + "\n\n❌ RAD ETILDI")
    except TelegramBadRequest:
        pass
    await call.answer("❌ Rad etildi.")
    try:
        await bot.send_message(
            user["telegram_id"],
            "❌ Kechirasiz, to'lovingiz tasdiqlanmadi. Savollar bo'lsa admin bilan bog'laning (🆘 Yordam).",
        )
    except Exception:
        pass


# ------------------------------------------------------------------ #
# VIP narxlari
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:vip_prices")
async def vip_prices_menu(call: CallbackQuery, db: Database):
    p1 = await db.get_setting("vip_price_1", "0")
    p2 = await db.get_setting("vip_price_2", "0")
    p3 = await db.get_setting("vip_price_3", "0")
    text = (
        "💰 <b>VIP narxlari</b>\n\n"
        f"1 oylik: {fmt_number(p1)} so'm\n"
        f"2 oylik: {fmt_number(p2)} so'm\n"
        f"3 oylik: {fmt_number(p3)} so'm"
    )
    await call.message.edit_text(text, reply_markup=kb.vip_prices_menu())
    await call.answer()


@router.callback_query(F.data.startswith("adm:set_price:"))
async def set_price_start(call: CallbackQuery, state: FSMContext):
    months = call.data.split(":")[2]
    state_map = {
        "1": AdminTextStates.waiting_vip_price_1,
        "2": AdminTextStates.waiting_vip_price_2,
        "3": AdminTextStates.waiting_vip_price_3,
    }
    await state.set_state(state_map[months])
    await call.message.answer(f"💰 {months} oylik VIP uchun yangi narxni kiriting (faqat raqam, so'mda):",
                               reply_markup=kb.cancel_menu())
    await call.answer()


async def _save_price(message: Message, state: FSMContext, db: Database, key: str):
    if not message.text:
        await message.answer("Iltimos faqat raqam kiriting.")
        return
    txt = message.text.strip().replace(" ", "")
    if not txt.isdigit():
        await message.answer("Iltimos faqat raqam kiriting.")
        return
    await db.set_setting(key, txt)
    await state.clear()
    await message.answer("✅ Narx yangilandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


@router.message(AdminTextStates.waiting_vip_price_1)
async def save_price_1(message: Message, state: FSMContext, db: Database):
    await _save_price(message, state, db, "vip_price_1")


@router.message(AdminTextStates.waiting_vip_price_2)
async def save_price_2(message: Message, state: FSMContext, db: Database):
    await _save_price(message, state, db, "vip_price_2")


@router.message(AdminTextStates.waiting_vip_price_3)
async def save_price_3(message: Message, state: FSMContext, db: Database):
    await _save_price(message, state, db, "vip_price_3")


# ------------------------------------------------------------------ #
# To'lov ma'lumotlari (karta)
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:payment_info")
async def payment_info(call: CallbackQuery, db: Database):
    number = await db.get_setting("payment_card_number", "—")
    holder = await db.get_setting("payment_card_holder", "—")
    text = f"💳 <b>To'lov ma'lumotlari</b>\n\nKarta: <code>{number}</code>\nEgasi: {holder}"
    await call.message.edit_text(text, reply_markup=kb.payment_info_menu())
    await call.answer()


@router.callback_query(F.data == "adm:set_card_number")
async def set_card_number_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminTextStates.waiting_card_number)
    await call.message.answer("💳 Yangi karta raqamini kiriting:", reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(AdminTextStates.waiting_card_number)
async def save_card_number(message: Message, state: FSMContext, db: Database):
    if not message.text:
        await message.answer("✏️ Iltimos, matn yuboring.")
        return
    await db.set_setting("payment_card_number", message.text.strip())
    await state.clear()
    await message.answer("✅ Saqlandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


@router.callback_query(F.data == "adm:set_card_holder")
async def set_card_holder_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminTextStates.waiting_card_holder)
    await call.message.answer("👤 Karta egasining ismini kiriting:", reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(AdminTextStates.waiting_card_holder)
async def save_card_holder(message: Message, state: FSMContext, db: Database):
    if not message.text:
        await message.answer("✏️ Iltimos, matn yuboring.")
        return
    await db.set_setting("payment_card_holder", message.text.strip())
    await state.clear()
    await message.answer("✅ Saqlandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


# ------------------------------------------------------------------ #
# /start rasm/matn
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:start_settings")
async def start_settings(call: CallbackQuery):
    await call.message.edit_text("🖼 /start sozlamalari:", reply_markup=kb.start_settings_menu())
    await call.answer()


@router.callback_query(F.data == "adm:set_start_text")
async def set_start_text_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminTextStates.waiting_start_text)
    await call.message.answer("✏️ Yangi /start matnini kiriting (HTML teglar ishlaydi):",
                               reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(AdminTextStates.waiting_start_text)
async def save_start_text(message: Message, state: FSMContext, db: Database):
    if not message.text:
        await message.answer("✏️ Iltimos, matn yuboring.")
        return
    await db.set_setting("start_text", message.html_text or message.text)
    await state.clear()
    await message.answer("✅ Matn yangilandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


@router.callback_query(F.data == "adm:set_start_photo")
async def set_start_photo_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminTextStates.waiting_start_photo)
    await call.message.answer("🖼 Yangi rasmni yuboring:", reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(AdminTextStates.waiting_start_photo, F.photo)
async def save_start_photo(message: Message, state: FSMContext, db: Database):
    await db.set_setting("start_photo_file_id", message.photo[-1].file_id)
    await state.clear()
    await message.answer("✅ Rasm yangilandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


@router.message(AdminTextStates.waiting_start_photo)
async def save_start_photo_wrong(message: Message):
    await message.answer("🖼 Iltimos rasm yuboring.")


# ------------------------------------------------------------------ #
# Yordam matni
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:help_settings")
async def help_settings(call: CallbackQuery):
    await call.message.edit_text("🆘 Yordam sozlamalari:", reply_markup=kb.help_settings_menu())
    await call.answer()


@router.callback_query(F.data == "adm:set_help_text")
async def set_help_text_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminTextStates.waiting_help_text)
    await call.message.answer("✏️ Yangi yordam matnini kiriting:", reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(AdminTextStates.waiting_help_text)
async def save_help_text(message: Message, state: FSMContext, db: Database):
    if not message.text:
        await message.answer("✏️ Iltimos, matn yuboring.")
        return
    await db.set_setting("help_text", message.html_text or message.text)
    await state.clear()
    await message.answer("✅ Yangilandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


@router.callback_query(F.data == "adm:set_help_admin")
async def set_help_admin_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminTextStates.waiting_help_admin_username)
    await call.message.answer("👤 Admin username kiriting (masalan: @username):", reply_markup=kb.cancel_menu())
    await call.answer()


@router.message(AdminTextStates.waiting_help_admin_username)
async def save_help_admin(message: Message, state: FSMContext, db: Database):
    if not message.text:
        await message.answer("✏️ Iltimos, matn yuboring (masalan: @username).")
        return
    await db.set_setting("help_admin_username", message.text.strip().lstrip("@"))
    await state.clear()
    await message.answer("✅ Yangilandi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


# ------------------------------------------------------------------ #
# Majburiy obuna kanallari
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:channels")
async def channels_menu_open(call: CallbackQuery, db: Database):
    channels = await db.list_required_channels()
    text = "📢 <b>Majburiy obuna kanallari</b>\n\nO'chirish uchun kanalga bosing." if channels else \
        "📢 Hozircha majburiy kanal qo'shilmagan."
    await call.message.edit_text(text, reply_markup=kb.channels_menu(channels))
    await call.answer()


@router.callback_query(F.data == "adm:add_channel")
async def add_channel_start(call: CallbackQuery, state: FSMContext):
    await state.set_state(AdminTextStates.waiting_required_channel)
    await call.message.answer(
        "➕ Kanal username (@kanal) yoki ID (-100...) va nomini yuboring.\n"
        "Format: <code>@kanal | Kanal nomi</code>\n\n"
        "❗ Bot kanalga admin qilib qo'shilgan bo'lishi shart (obunani tekshirish uchun).",
        reply_markup=kb.cancel_menu(),
    )
    await call.answer()


@router.message(AdminTextStates.waiting_required_channel)
async def add_channel_save(message: Message, state: FSMContext, db: Database):
    if not message.text:
        await message.answer("✏️ Iltimos, matn yuboring. Format: @kanal | Kanal nomi")
        return
    parts = message.text.split("|", 1)
    chat_id = parts[0].strip()
    title = parts[1].strip() if len(parts) > 1 else chat_id
    await db.add_required_channel(chat_id, title)
    await state.clear()
    await message.answer("✅ Kanal qo'shildi.", reply_markup=kb.main_menu(is_admin=True))
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())


@router.callback_query(F.data.startswith("adm:del_channel:"))
async def del_channel(call: CallbackQuery, db: Database):
    channel_pk = int(call.data.split(":")[2])
    await db.remove_required_channel(channel_pk)
    channels = await db.list_required_channels()
    await call.message.edit_text(
        "📢 <b>Majburiy obuna kanallari</b>" if channels else "📢 Hozircha majburiy kanal qo'shilmagan.",
        reply_markup=kb.channels_menu(channels),
    )
    await call.answer("O'chirildi.")


# ------------------------------------------------------------------ #
# Backup
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:backup")
async def do_backup(call: CallbackQuery, db: Database):
    path = await db.backup()
    try:
        from aiogram.types import FSInputFile
        await call.message.answer_document(FSInputFile(path), caption="💾 Zaxira nusxa tayyor.")
    except Exception:
        await call.message.answer(f"💾 Zaxira nusxa yaratildi: {path}")
    await call.answer()


# ------------------------------------------------------------------ #
# Broadcast
# ------------------------------------------------------------------ #
@router.callback_query(F.data == "adm:broadcast")
async def broadcast_start(call: CallbackQuery, state: FSMContext, db: Database):
    # Agar hozir faol (yoki pauzadagi) reklama bo'lsa — yangisini so'ramay,
    # o'shaning holatini (⏸/▶️ tugmalari bilan) ko'rsatamiz.
    active = await db.get_latest_active_broadcast()
    if active:
        paused = active["status"] == "paused"
        status_txt = "⏸ To'xtatilgan" if paused else "▶️ Yuborilmoqda"
        text = (
            f"📢 <b>Reklama</b>\n\n"
            f"Holati: {status_txt}\n"
            f"Yuborildi: {active['sent_count'] + active['failed_count']}/{active['total_count']} "
            f"(✅ {active['sent_count']} | ❌ {active['failed_count']})"
        )
        await call.message.answer(text, reply_markup=kb.broadcast_control_keyboard(active["id"], paused))
        await call.answer()
        return

    await state.set_state(BroadcastStates.waiting_content)
    await call.message.answer(
        "📢 Barcha foydalanuvchilarga yuboriladigan xabarni yuboring "
        "(matn, rasm, video — istalgan turdagi xabar bo'lishi mumkin):",
        reply_markup=kb.cancel_menu(),
    )
    await call.answer()


@router.message(BroadcastStates.waiting_content)
async def broadcast_receive(message: Message, state: FSMContext, db: Database, bot: Bot):
    await state.clear()
    user = await ensure_user(db, message.from_user)
    ids = await db.all_telegram_ids()
    broadcast_id = await db.create_broadcast(
        content_type="copy",
        payload=json.dumps({"chat_id": message.chat.id, "message_id": message.message_id}),
        total=len(ids),
        created_by=message.from_user.id,
    )
    _broadcast_flags[broadcast_id] = {"paused": False}
    status_msg = await message.answer(
        f"📢 Yuborish boshlandi: 0/{len(ids)}",
        reply_markup=kb.broadcast_control_keyboard(broadcast_id, paused=False),
    )
    await message.answer("⚙️ Admin panel:", reply_markup=kb.admin_panel_menu())
    asyncio.create_task(_run_broadcast(bot, db, broadcast_id, ids, message.chat.id,
                                        message.message_id, status_msg.chat.id, status_msg.message_id))


async def _run_broadcast(bot: Bot, db: Database, broadcast_id: int, user_ids: list[int],
                          src_chat_id: int, src_message_id: int, status_chat_id: int, status_message_id: int):
    sent, failed = 0, 0
    for uid in user_ids:
        flags = _broadcast_flags.get(broadcast_id, {})
        while flags.get("paused"):
            await asyncio.sleep(2)
            flags = _broadcast_flags.get(broadcast_id, {})
        try:
            await bot.copy_message(chat_id=uid, from_chat_id=src_chat_id, message_id=src_message_id)
            sent += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await bot.copy_message(chat_id=uid, from_chat_id=src_chat_id, message_id=src_message_id)
                sent += 1
            except Exception:
                failed += 1
        except (TelegramForbiddenError, TelegramBadRequest):
            failed += 1
        except Exception:
            failed += 1
        await db.update_broadcast_progress(broadcast_id, sent, failed)
        if (sent + failed) % 25 == 0:
            try:
                await bot.edit_message_text(
                    f"📢 Yuborilmoqda: {sent + failed}/{len(user_ids)} "
                    f"(✅ {sent} | ❌ {failed})",
                    chat_id=status_chat_id, message_id=status_message_id,
                    reply_markup=kb.broadcast_control_keyboard(broadcast_id, paused=False),
                )
            except Exception:
                pass
        await asyncio.sleep(0.05)  # Telegram limitlariga hurmat

    await db.set_broadcast_status(broadcast_id, "done")
    _broadcast_flags.pop(broadcast_id, None)
    try:
        await bot.edit_message_text(
            f"✅ Yuborish tugadi: {sent + failed}/{len(user_ids)} (✅ {sent} | ❌ {failed})",
            chat_id=status_chat_id, message_id=status_message_id,
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("adm:bc_pause:"))
async def bc_pause(call: CallbackQuery, db: Database):
    broadcast_id = int(call.data.split(":")[2])
    _broadcast_flags.setdefault(broadcast_id, {})["paused"] = True
    await db.set_broadcast_status(broadcast_id, "paused")
    try:
        await call.message.edit_reply_markup(reply_markup=kb.broadcast_control_keyboard(broadcast_id, paused=True))
    except TelegramBadRequest:
        pass
    await call.answer("⏸ To'xtatildi.")


@router.callback_query(F.data.startswith("adm:bc_resume:"))
async def bc_resume(call: CallbackQuery, db: Database):
    broadcast_id = int(call.data.split(":")[2])
    _broadcast_flags.setdefault(broadcast_id, {})["paused"] = False
    await db.set_broadcast_status(broadcast_id, "running")
    try:
        await call.message.edit_reply_markup(reply_markup=kb.broadcast_control_keyboard(broadcast_id, paused=False))
    except TelegramBadRequest:
        pass
    await call.answer("▶️ Davom ettirildi.")
